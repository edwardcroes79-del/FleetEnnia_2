import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/database.types";

export type Role = "admin" | "director" | "employee";
export type Vehicle = Tables<"vehicles">;
export type VehicleInsert = TablesInsert<"vehicles">;
export type VehicleUpdate = TablesUpdate<"vehicles">;
export type Profile = Tables<"profiles">;
export type Employee = Profile;
export type Assignment = Tables<"assignments">;
export type AssignmentWithRelations = Assignment & { vehicle: Vehicle; employee: Employee };
export type Maintenance = Tables<"maintenance">;
export type MaintenanceWithVehicle = Maintenance & { vehicle: Pick<Vehicle, "vehicle_id" | "make" | "model" | "is_deleted"> };
export type FuelLog = Tables<"fuel_log">;
export type FuelLogWithRelations = FuelLog & { vehicle: Pick<Vehicle, "vehicle_id" | "make" | "model">; driver: Pick<Employee, "full_name"> | null };
export type Incident = Tables<"incidents">;
export type IncidentWithRelations = Incident & { vehicle: Pick<Vehicle, "vehicle_id" | "make" | "model">; reporter: Pick<Employee, "full_name"> | null };
export type Document = Tables<"documents">;
export type DocumentWithRelations = Document & { vehicle: Pick<Vehicle, "vehicle_id" | "make" | "model"> | null; employee: Pick<Employee, "full_name"> | null };
export type FleetDocument = Document;

export type IncidentType = {
  id: string;
  name: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

export type MaintenanceType = {
  id: string;
  name: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

export const vehicleService = {
  async list(activeOnly = true): Promise<{ data: Vehicle[]; error: Error | null }> {
    let q = supabase.from("vehicles").select("*").order("created_at", { ascending: false });
    if (activeOnly) q = q.eq("is_deleted", false);
    const { data, error } = await q;
    return { data: (data ?? []) as Vehicle[], error };
  },
  async get(id: string): Promise<{ data: Vehicle | null; error: Error | null }> {
    const { data, error } = await supabase.from("vehicles").select("*").eq("id", id).maybeSingle();
    return { data: data as Vehicle | null, error };
  },
  async create(values: VehicleInsert): Promise<{ data: Vehicle | null; error: Error | null }> {
    const { data, error } = await supabase.from("vehicles").insert(values).select().single();
    return { data: data as Vehicle | null, error };
  },
  async update(id: string, values: VehicleUpdate): Promise<{ data: Vehicle | null; error: Error | null }> {
    const { data, error } = await supabase.from("vehicles").update(values).eq("id", id).select().single();
    return { data: data as Vehicle | null, error };
  },
  async softDelete(id: string) {
    return await supabase.from("vehicles").update({ is_deleted: true, status: "Retired" }).eq("id", id);
  },
};

export const profileService = {
  async list(activeOnly = true): Promise<{ data: Employee[]; error: Error | null }> {
    let q = supabase.from("profiles").select("*").order("full_name");
    if (activeOnly) q = q.eq("is_active", true);
    const { data, error } = await q;
    return { data: (data ?? []) as Employee[], error };
  },
  async get(id: string): Promise<{ data: Employee | null; error: Error | null }> {
    const { data, error } = await supabase.from("profiles").select("*").eq("id", id).maybeSingle();
    return { data: data as Employee | null, error };
  },
  async create(values: TablesInsert<"profiles">): Promise<{ data: Employee | null; error: Error | null }> {
    const { data, error } = await supabase.from("profiles").insert(values).select().single();
    return { data: data as Employee | null, error };
  },
  async update(id: string, values: TablesUpdate<"profiles">): Promise<{ data: Employee | null; error: Error | null }> {
    const { data, error } = await supabase.from("profiles").update(values).eq("id", id).select().single();
    return { data: data as Employee | null, error };
  },
  async softDelete(id: string) {
    return await supabase.from("profiles").update({ is_active: false }).eq("id", id);
  },
  async hardDelete(id: string): Promise<{ error: Error | null }> {
    const res = await fetch("/api/admin/delete-employee", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    if (!res.ok) {
      const err = await res.json();
      return { error: new Error(err.error || "Failed to delete") };
    }
    return { error: null };
  },
  async updateViaApi(id: string, values: Partial<Omit<Employee, "id" | "email" | "role" | "created_at" | "updated_at" | "avatar_url">>): Promise<{ data: Employee | null; error: Error | null }> {
    const res = await fetch("/api/admin/update-employee", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, ...values }),
    });
    if (!res.ok) {
      const err = await res.json();
      return { data: null, error: new Error(err.error || "Failed to update employee") };
    }
    const body = await res.json();
    return { data: body.data as Employee, error: null };
  },
};

export const employeeService = profileService;

export const assignmentService = {
  async list(): Promise<{ data: AssignmentWithRelations[]; error: Error | null }> {
    const { data, error } = await supabase
      .from("assignments")
      .select("*, vehicle:vehicles(*), employee:profiles!employee_id(*)")
      .order("created_at", { ascending: false });
    return { data: (data ?? []) as unknown as AssignmentWithRelations[], error };
  },
  async get(id: string): Promise<{ data: Assignment | null; error: Error | null }> {
    const { data, error } = await supabase.from("assignments").select("*").eq("id", id).maybeSingle();
    return { data: data as Assignment | null, error };
  },
  async create(values: TablesInsert<"assignments">): Promise<{ data: Assignment | null; error: Error | null }> {
    const { data, error } = await supabase.from("assignments").insert(values).select().single();
    return { data: data as Assignment | null, error };
  },
  async update(id: string, values: TablesUpdate<"assignments">): Promise<{ data: Assignment | null; error: Error | null }> {
    const { data, error } = await supabase.from("assignments").update(values).eq("id", id).select().single();
    return { data: data as Assignment | null, error };
  },
  async close(id: string, values: TablesUpdate<"assignments">): Promise<{ data: Assignment | null; error: Error | null }> {
    const { data, error } = await supabase
      .from("assignments")
      .update({ ...values, is_active: false })
      .eq("id", id)
      .select()
      .single();
    return { data: data as Assignment | null, error };
  },
};

export const maintenanceService = {
  async list(): Promise<{ data: MaintenanceWithVehicle[]; error: Error | null }> {
    const { data, error } = await supabase
      .from("maintenance")
      .select("*, vehicle:vehicles(vehicle_id, make, model, is_deleted)")
      .eq("is_deleted", false)
      .order("service_date", { ascending: false });
    return { data: (data ?? []) as unknown as MaintenanceWithVehicle[], error };
  },
  async get(id: string): Promise<{ data: Maintenance | null; error: Error | null }> {
    const { data, error } = await supabase.from("maintenance").select("*").eq("id", id).maybeSingle();
    return { data: data as Maintenance | null, error };
  },
  async create(values: TablesInsert<"maintenance">): Promise<{ data: Maintenance | null; error: Error | null }> {
    const { data, error } = await supabase.from("maintenance").insert(values).select().single();
    return { data: data as Maintenance | null, error };
  },
  async update(id: string, values: TablesUpdate<"maintenance">): Promise<{ data: Maintenance | null; error: Error | null }> {
    const { data, error } = await supabase.from("maintenance").update(values).eq("id", id).select().single();
    return { data: data as Maintenance | null, error };
  },
  async softDelete(id: string): Promise<{ error: Error | null }> {
    const { error } = await supabase.from("maintenance").update({ is_deleted: true }).eq("id", id);
    return { error };
  },
};

export const maintenanceTypeService = {
  async list(): Promise<{ data: MaintenanceType[]; error: Error | null }> {
    const { data, error } = await supabase
      .from("maintenance_types")
      .select("*")
      .eq("is_active", true)
      .order("name");
    return { data: (data ?? []) as MaintenanceType[], error };
  },
  async create(name: string): Promise<{ data: MaintenanceType | null; error: Error | null }> {
    const { data, error } = await supabase.from("maintenance_types").insert({ name }).select().single();
    return { data: data as MaintenanceType | null, error };
  },
  async update(id: string, values: Partial<MaintenanceType>): Promise<{ data: MaintenanceType | null; error: Error | null }> {
    const { data, error } = await supabase.from("maintenance_types").update(values).eq("id", id).select().single();
    return { data: data as MaintenanceType | null, error };
  },
};

export const fuelService = {
  async list(): Promise<{ data: FuelLogWithRelations[]; error: Error | null }> {
    const { data, error } = await supabase
      .from("fuel_log")
      .select("*, vehicle:vehicles(vehicle_id, make, model), driver:profiles!driver_id(full_name)")
      .order("fuel_date", { ascending: false });
    return { data: (data ?? []) as unknown as FuelLogWithRelations[], error };
  },
  async get(id: string): Promise<{ data: FuelLog | null; error: Error | null }> {
    const { data, error } = await supabase.from("fuel_log").select("*").eq("id", id).maybeSingle();
    return { data: data as FuelLog | null, error };
  },
  async create(values: TablesInsert<"fuel_log">): Promise<{ data: FuelLog | null; error: Error | null }> {
    const { data, error } = await supabase.from("fuel_log").insert(values).select().single();
    return { data: data as FuelLog | null, error };
  },
  async update(id: string, values: TablesUpdate<"fuel_log">): Promise<{ data: FuelLog | null; error: Error | null }> {
    const { data, error } = await supabase.from("fuel_log").update(values).eq("id", id).select().single();
    return { data: data as FuelLog | null, error };
  },
};

export const incidentService = {
  async list(): Promise<{ data: IncidentWithRelations[]; error: Error | null }> {
    const { data, error } = await supabase
      .from("incidents")
      .select("*, vehicle:vehicles(vehicle_id, make, model), reporter:profiles!reporter_id(full_name)")
      .order("created_at", { ascending: false });
    return { data: (data ?? []) as unknown as IncidentWithRelations[], error };
  },
  async get(id: string): Promise<{ data: Incident | null; error: Error | null }> {
    const { data, error } = await supabase.from("incidents").select("*").eq("id", id).maybeSingle();
    return { data: data as Incident | null, error };
  },
  async create(values: TablesInsert<"incidents">): Promise<{ data: Incident | null; error: Error | null }> {
    const { data, error } = await supabase.from("incidents").insert(values).select().single();
    return { data: data as Incident | null, error };
  },
  async update(id: string, values: TablesUpdate<"incidents">): Promise<{ data: Incident | null; error: Error | null }> {
    const { data, error } = await supabase.from("incidents").update(values).eq("id", id).select().single();
    return { data: data as Incident | null, error };
  },
};

export const incidentTypeService = {
  async list(): Promise<{ data: IncidentType[]; error: Error | null }> {
    const { data, error } = await supabase
      .from("incident_types")
      .select("*")
      .eq("is_active", true)
      .order("name");
    return { data: (data ?? []) as IncidentType[], error };
  },
  async create(name: string): Promise<{ data: IncidentType | null; error: Error | null }> {
    const { data, error } = await supabase.from("incident_types").insert({ name }).select().single();
    return { data: data as IncidentType | null, error };
  },
  async update(id: string, values: Partial<IncidentType>): Promise<{ data: IncidentType | null; error: Error | null }> {
    const { data, error } = await supabase.from("incident_types").update(values).eq("id", id).select().single();
    return { data: data as IncidentType | null, error };
  },
};

export const incidentPhotoService = {
  async upload(file: File): Promise<{ publicUrl: string | null; error: Error | null }> {
    const ext = file.name.split(".").pop() || "jpg";
    const path = `${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("incident_photos").upload(path, file, {
      cacheControl: "3600",
      upsert: true,
    });
    if (error) return { publicUrl: null, error };
    const { data } = supabase.storage.from("incident_photos").getPublicUrl(path);
    return { publicUrl: data.publicUrl, error: null };
  },
};

export const incidentDocumentService = {
  async upload(file: File): Promise<{ publicUrl: string | null; error: Error | null }> {
    const ext = file.name.split(".").pop() || "pdf";
    const path = `${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("incident_documents").upload(path, file, {
      cacheControl: "3600",
      upsert: true,
      contentType: file.type || "application/pdf",
    });
    if (error) return { publicUrl: null, error };
    const { data } = supabase.storage.from("incident_documents").getPublicUrl(path);
    return { publicUrl: data.publicUrl, error: null };
  },
};

export const documentService = {
  async list(): Promise<{ data: DocumentWithRelations[]; error: Error | null }> {
    const { data, error } = await supabase
      .from("documents")
      .select("*, vehicle:vehicles(vehicle_id, make, model), employee:profiles!employee_id(full_name)")
      .order("created_at", { ascending: false });
    return { data: (data ?? []) as unknown as DocumentWithRelations[], error };
  },
  async get(id: string): Promise<{ data: Document | null; error: Error | null }> {
    const { data, error } = await supabase.from("documents").select("*").eq("id", id).maybeSingle();
    return { data: data as Document | null, error };
  },
  async create(values: TablesInsert<"documents">): Promise<{ data: Document | null; error: Error | null }> {
    const { data, error } = await supabase.from("documents").insert(values).select().single();
    return { data: data as Document | null, error };
  },
  async update(id: string, values: TablesUpdate<"documents">): Promise<{ data: Document | null; error: Error | null }> {
    const { data, error } = await supabase.from("documents").update(values).eq("id", id).select().single();
    return { data: data as Document | null, error };
  },
  async delete(id: string): Promise<{ error: Error | null }> {
    const { error } = await supabase.from("documents").delete().eq("id", id);
    return { error };
  },
};

export const dashboardService = {
  async stats() {
    const { data: vehicles, error: vErr } = await supabase.from("vehicles").select("status, insurance_expiry, registration_expiry, service_due_date").eq("is_deleted", false);
    if (vErr) return { data: null, error: vErr };
    const in30 = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    const in7 = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    const counts = { Available: 0, Assigned: 0, Maintenance: 0, Retired: 0 };
    (vehicles ?? []).forEach((v) => { counts[v.status as keyof typeof counts] = (counts[v.status as keyof typeof counts] ?? 0) + 1; });
    const alerts = (vehicles ?? []).filter((v) =>
      (v.insurance_expiry && v.insurance_expiry <= in30) ||
      (v.registration_expiry && v.registration_expiry <= in30) ||
      (v.service_due_date && v.service_due_date <= in7)
    );
    return { data: { counts, total: (vehicles ?? []).length, alerts }, error: null };
  },
  async recentActivity(limit = 5) {
    const { data, error } = await supabase
      .from("audit_log")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(limit);
    return { data: (data ?? []), error };
  },
};

export const vehiclePhotoService = {
  async upload(file: File, vehicleId: string): Promise<{ path: string | null; publicUrl: string | null; error: Error | null }> {
    const ext = file.name.split(".").pop() || "jpg";
    const path = `${vehicleId}/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("vehicle-photos").upload(path, file, {
      cacheControl: "3600",
      upsert: true,
    });
    if (error) return { path: null, publicUrl: null, error };
    const { data } = supabase.storage.from("vehicle-photos").getPublicUrl(path);
    return { path, publicUrl: data.publicUrl, error: null };
  },
};